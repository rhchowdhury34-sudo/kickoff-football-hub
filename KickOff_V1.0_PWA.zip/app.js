const matches = [
 {league:"Premier League",home:"Arsenal",away:"Chelsea",h:2,a:1,time:"FT",state:"Finished",icons:["🔴","🔵"]},
 {league:"La Liga",home:"Real Madrid",away:"Barcelona",h:null,a:null,time:"20:00",state:"Upcoming",icons:["⚪","🔵"]},
 {league:"Premier League",home:"Liverpool",away:"Man City",h:null,a:null,time:"22:30",state:"Upcoming",icons:["🔴","🩵"]},
 {league:"Champions League",home:"Bayern",away:"PSG",h:1,a:1,time:"67'",state:"Live",icons:["🔴","🔵"]}
];
const leagues = [
 ["🏴","Premier League","England"],["🇪🇸","La Liga","Spain"],["🇩🇪","Bundesliga","Germany"],
 ["🇮🇹","Serie A","Italy"],["🇫🇷","Ligue 1","France"],["⭐","Champions League","Europe"]
];
const news = [
 ["TRANSFER WATCH","Transfer window: the stories to follow","Transfer desk · 4 min read","🔁"],
 ["MATCHDAY","Five things to watch this football weekend","Football desk · 3 min read","⚽"],
 ["ANALYSIS","How modern pressing is changing the game","Tactics · 6 min read","📊"]
];
const main = document.getElementById("mainContent");
const toastEl = document.getElementById("toast");
let currentPage = "Home";
let activeFilter = "All";
let deferredPrompt = null;

function toast(message){toastEl.textContent=message;toastEl.classList.add("show");setTimeout(()=>toastEl.classList.remove("show"),2200)}
function matchCard(m){
 const score = m.state==="Upcoming" ? `<div class="score"><small>${m.time}</small></div>` : `<div class="score">${m.h} <small>–</small> ${m.a}</div>`;
 return `<article class="match-card"><div class="match-meta"><span>${m.league}</span><span class="status ${m.state.toLowerCase()}">${m.state==="Live"?"● LIVE":m.state.toUpperCase()}</span></div><div class="match-teams"><div class="team"><span class="crest">${m.icons[0]}</span><span>${m.home}</span></div>${score}<div class="team"><span>${m.away}</span><span class="crest">${m.icons[1]}</span></div></div></article>`;
}
function renderHome(){
 main.innerHTML = `<section class="hero"><div class="hero-kicker"><span class="pulse-dot"></span> YOUR FOOTBALL CENTRAL</div><h1>The game<br><span class="lime">never stops.</span></h1><p>Scores, fixtures, leagues and stories — all in one place.</p><button class="primary-btn" data-go="Scores">Explore matches <span>→</span></button><div class="hero-ball">⚽</div></section>
 <section class="section"><div class="section-heading"><div><p class="eyebrow">DON'T MISS A MOMENT</p><h2>Match centre</h2></div><button class="text-btn" data-go="Scores">View all ↗</button></div><div class="filter-row">${["All","Live","Upcoming","Finished"].map(f=>`<button class="chip ${activeFilter===f?"active":""}" data-filter="${f}">${f}</button>`).join("")}</div><div class="match-list">${matches.filter(m=>activeFilter==="All"||m.state===activeFilter).map(matchCard).join("")||'<div class="empty">No matches in this category.</div>'}</div></section>
 <section class="section"><div class="section-heading"><div><p class="eyebrow">FOLLOW THE BIGGEST</p><h2>Top leagues</h2></div><button class="text-btn" data-go="Leagues">All leagues ↗</button></div><div class="league-strip">${leagues.slice(0,4).map(l=>`<button class="league-tile" data-league="${l[1]}"><span class="league-icon">${l[0]}</span><span><strong>${l[1]}</strong><small>${l[2]}</small></span></button>`).join("")}</div></section>
 <section class="section"><div class="section-heading"><div><p class="eyebrow">AROUND THE WORLD</p><h2>Latest stories</h2></div><button class="text-btn" data-go="News">More news ↗</button></div>${newsHTML()}</section>`;
}
function newsHTML(){return `<div class="news-list">${news.map(n=>`<article class="news-card"><div class="news-art">${n[3]}</div><div><small>${n[0]}</small><h3>${n[1]}</h3><p>${n[2]}</p></div></article>`).join("")}</div>`}
function renderPage(page){
 currentPage=page;
 document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("selected",b.dataset.page===page));
 if(page==="Home"){renderHome();return}
 let content="";
 if(page==="Scores") content=`<p class="eyebrow">ALL THE ACTION</p><h1 class="page-title">Match centre</h1><p class="subcopy">Follow matchday action from leagues around the world.</p><div class="filter-row">${["All","Live","Upcoming","Finished"].map(f=>`<button class="chip ${activeFilter===f?"active":""}" data-filter="${f}">${f}</button>`).join("")}</div><div class="match-list">${matches.filter(m=>activeFilter==="All"||m.state===activeFilter).map(matchCard).join("")}</div><p class="subcopy">Demo scores only. Connect a verified football data provider to show real-time results.</p>`;
 if(page==="Fixtures") content=`<p class="eyebrow">PLAN YOUR MATCHDAY</p><h1 class="page-title">Fixtures & results</h1><p class="subcopy">Upcoming fixtures and completed matches in one place.</p><div class="match-list">${matches.map(matchCard).join("")}</div>`;
 if(page==="Leagues") content=`<p class="eyebrow">THE BIG COMPETITIONS</p><h1 class="page-title">Explore leagues</h1><div class="league-strip">${leagues.map(l=>`<button class="league-tile" data-league="${l[1]}"><span class="league-icon">${l[0]}</span><span><strong>${l[1]}</strong><small>${l[2]}</small></span></button>`).join("")}</div><h2 style="font-size:18px;margin:26px 0 12px">Premier League · Sample table</h2><div class="table-wrap"><table><thead><tr><th>CLUB</th><th>P</th><th>W</th><th>D</th><th>L</th><th>PTS</th></tr></thead><tbody>${[["1","Arsenal",10,8,1,1,25],["2","Man City",10,7,2,1,23],["3","Liverpool",10,7,1,2,22],["4","Chelsea",10,6,2,2,20],["5","Spurs",10,5,2,3,17]].map(r=>`<tr><td class="team-cell">${r[0]}. ${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${r[4]}</td><td>${r[5]}</td><td><b>${r[6]}</b></td></tr>`).join("")}</tbody></table></div><p class="subcopy">Illustrative standings — not current official league data.</p>`;
 if(page==="News") content=`<p class="eyebrow">THE LATEST FROM THE GAME</p><h1 class="page-title">Football news</h1><p class="subcopy">Stories, analysis and transfer updates. News cards are placeholders until a trusted news source is connected.</p>${newsHTML()}`;
 main.innerHTML=`<section class="section" style="padding-top:24px">${content}</section>`;
}
document.addEventListener("click",e=>{
 const go=e.target.closest("[data-go]"); if(go){renderPage(go.dataset.go);window.scrollTo(0,0);return}
 const nav=e.target.closest("[data-page]");if(nav){renderPage(nav.dataset.page);window.scrollTo(0,0);return}
 const filter=e.target.closest("[data-filter]");if(filter){activeFilter=filter.dataset.filter;renderPage(currentPage);return}
 const league=e.target.closest("[data-league]");if(league){toast(`${league.dataset.league} selected — data connection coming next`);return}
});
document.getElementById("searchBtn").addEventListener("click",()=>toast("Search will be enabled in a future update."));
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;document.getElementById("installBtn").hidden=false});
document.getElementById("installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;document.getElementById("installBtn").hidden=true});
if("serviceWorker" in navigator && (location.protocol==="https:"||location.hostname==="localhost")){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}
renderHome();
